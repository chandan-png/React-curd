import React from "react";


const About = () =>{
    return(
        <div className="contanier"> 
          <div className= "py-4">
         <h1> About page</h1>
         <p className="lead">Be sure to have your pages set up with the latest design and development standards. That means using an HTML5 doctype and including a viewport meta tag for proper responsive behaviors. Put it all together and your pages should look like this: </p>
         <p className="lead">Be sure to have your pages set up with the latest design and development standards. That means using an HTML5 doctype and including a viewport meta tag for proper responsive behaviors. Put it all together and your pages should look like this: </p>
         <p className="lead">Be sure to have your pages set up with the latest design and development standards. That means using an HTML5 doctype and including a viewport meta tag for proper responsive behaviors. Put it all together and your pages should look like this: </p>

           </div>
        </div>
    );  
};
export default About;