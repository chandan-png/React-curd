import 'bootstrap/dist/css/bootstrap.min.css';
import "../node_modules/bootstrap/dist/css/bootstrap.css"
import Navbar from './components/Layout/Navbar';
import { Routes, Route } from "react-router-dom";
import Home from "./components/Pages/Home";
import About from "./components/Pages/About";
import Contact from "./components/Pages/Contact";
import Notfound from "./components/Pages/Page Not found"
import Adduser from './components/Users/Adduser';
import Edituser from './components/Users/Edituser';

function App() {
  return (
    <>
      <Navbar />


      <Routes>

        <Route path="/" element={<Home />} />
        <Route path="/About" exact element={<About />} />
        <Route path="/Contact" element={<Contact />} />
        <Route path="/Users/add" element={<Adduser />} />
        <Route path="/Users/edit/:id" element={<Edituser/>}/>
        <Route component={Notfound}/>
      </Routes>
    </>
  );
}

export default App;
